\contentsline {lstlisting}{\numberline {1}{\ignorespaces Definicja struktury węzła Node}}{5}{lstlisting.1}%
\contentsline {lstlisting}{\numberline {2}{\ignorespaces Rekurencyjna metoda insertRecursive}}{13}{lstlisting.2}%
\contentsline {lstlisting}{\numberline {3}{\ignorespaces Zapis binarny drzewa w klasie FileManager}}{14}{lstlisting.3}%
